# ugc-sniper
the best one out there (yet again)

bored to explain how it works on github join my serv instead https://discord.gg/n2xfSuf7p8

tutorial (not by me) - https://docs.google.com/document/d/16VK4WM39sgjrkdN-u2dIzzL6wGgD89g4pQ-N-w3emOY/edit

## functions
- supports multi ids
- supports multi cookies
- is asynchronous that makes it able to mass buy items
- uses aiohttp
- supports every device (linux, windows, mac)
- supports discord webhooks

## usage
- format of multiple ids:  
- new line for every new id
   
- format of multiple Cookies:
- new line for every new cookie
                           
you don't need multiple ids and cookies one also works
                           
next update 300 stars (suggestions)


<a rel="license" href="http://creativecommons.org/licenses/by-nd/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-nd/4.0/88x31.png" /></a><br />This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-nd/4.0/">Creative Commons Attribution-NoDerivatives 4.0 International License</a>.
